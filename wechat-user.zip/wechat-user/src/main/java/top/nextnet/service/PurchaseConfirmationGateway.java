package top.nextnet.service;

public interface PurchaseConfirmationGateway {
    void confirmWeChatPurchase(int idWeChatPurchase);
}
